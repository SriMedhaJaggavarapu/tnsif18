package com.sriindu.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sriindu.admin.entity.Admin;
import com.sriindu.admin.service.AdminService;



@RestController
public class AdminController {

	@Autowired
	AdminService a1;
	
	@PostMapping("/admin")
	public Admin saveAdmin(@RequestBody Admin admin) {
		
		return a1.saveAdmin(admin);
	}
	
	
	@GetMapping("/admin")
    public List<Admin> fetchAdminList() {
        //LOGGER.info("Inside fetchAdminList of AdminController");
        return a1.fetchAdminList();
    }
	
	
	@GetMapping("/admin/{id}")
    public Admin fetchAdminById(@PathVariable("id") Long id)
            {
        return a1.fetchAdminById(id);
    }
	

	@DeleteMapping("/admin/{id}")
    public String deleteAdmintById(@PathVariable("id") Long id) {
        a1.deleteAdminById(id);
        return "Admin deleted Successfully!!";
    }

}
