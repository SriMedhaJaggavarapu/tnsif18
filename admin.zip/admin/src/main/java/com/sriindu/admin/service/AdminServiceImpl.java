package com.sriindu.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sriindu.admin.entity.Admin;
import com.sriindu.admin.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminRepository ar;

	@Override
	public Admin saveAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return ar.save(admin);
	}

	@Override
	public List<Admin> fetchAdminList() {
		// TODO Auto-generated method stub
		return ar.findAll();
	}

	@Override
	public Admin fetchAdminById(Long id) {
		// TODO Auto-generated method stub
		return  ar.findById(id).get();
	}

	@Override
	public void deleteAdminById(Long id) {
		// TODO Auto-generated method stub
		ar.deleteById(id);
		
	}
	
}
